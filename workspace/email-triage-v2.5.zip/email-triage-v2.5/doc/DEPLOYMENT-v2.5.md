# Email Triage — v2.5 Deployment Guide

## What changed from v2.4

### New files (install to workspace root)
| File | Role |
|---|---|
| `AGENTS.md` | Agent operational briefing — loaded at session start |
| `soul.md` | Agent voice and reply style — loaded at session start |
| `user.md` | Nay's profile and preferences — loaded at session start |

These three files are the **stable context layer**. They are loaded once when an
`openclaw agent --agent email-triage` session starts and never re-injected per call.

### Modified files
| File | Key change |
|---|---|
| `memory/triage-rules.md` | Reply style guide removed (moved to soul.md). Data only. |
| `scripts/dispatcher.sh` | PATH fixed for cron; gws → Maton; lobster via openclaw tool |
| `scripts/fetch-email.sh` | gws → Maton API Gateway |
| `scripts/classify-email.sh` | Prompt shortened (style no longer injected inline) |
| `scripts/draft-reply.sh` | triage-rules.md no longer loaded (style comes from soul.md) |
| `scripts/mark-processed.sh` | gws → Maton API Gateway |
| `scripts/route-and-act.sh` | gws → Maton; Telegram chat ID from env/secrets |
| `scripts/send-approved-reply.sh` | gws → Maton API Gateway |
| `scripts/setup-labels.sh` | gws → Maton; jq exit code 5 bug fixed |
| `config/openclaw-config-snippet.json5` | contextFiles wired; cron PATH fixed; gws MCP removed |
| `workflows/email-triage.lobster` | Comment update reflecting new invocation pattern |

---

## Installation steps

### 1. Copy new identity files to workspace root

```bash
cp AGENTS.md ~/.openclaw/workspace/AGENTS.md
cp soul.md ~/.openclaw/workspace/soul.md
cp user.md ~/.openclaw/workspace/user.md
```

### 2. Replace memory/triage-rules.md

```bash
cp memory/triage-rules.md ~/.openclaw/workspace/memory/triage-rules.md
```

### 3. Replace all scripts

```bash
cp scripts/*.sh ~/.openclaw/workspace/scripts/
chmod +x ~/.openclaw/workspace/scripts/*.sh
```

### 4. Replace workflow

```bash
cp workflows/email-triage.lobster ~/.openclaw/workspace/workflows/email-triage.lobster
```

### 5. Add MATON_API_KEY to secrets

```bash
echo "your-maton-api-key" > ~/.openclaw/secrets/maton-api-key
chmod 600 ~/.openclaw/secrets/maton-api-key
```

Then add to your shell profile and OpenClaw environment:
```bash
export MATON_API_KEY="$(cat ~/.openclaw/secrets/maton-api-key)"
```

### 6. Add Telegram chat ID to secrets (removes hardcoded ID)

```bash
echo "1771281565" > ~/.openclaw/secrets/telegram-chat-id
chmod 600 ~/.openclaw/secrets/telegram-chat-id
```

### 7. Update openclaw.json

Merge `config/openclaw-config-snippet.json5` into `~/.openclaw/openclaw.json`.
Key additions:
- `agents.list[0].contextFiles` — wires AGENTS.md, soul.md, user.md to the
  email-triage agent
- `cron.jobs[*].env.PATH` — fixes gws/jq/node not found in cron context

### 8. Re-register the email-triage agent

```bash
openclaw agents add email-triage \
  --model "anthropic/claude-haiku-4-5-20251001" \
  --workspace "/Users/aiagnet/.openclaw/workspace" \
  --context-file "/Users/aiagnet/.openclaw/workspace/AGENTS.md" \
  --context-file "/Users/aiagnet/.openclaw/workspace/soul.md" \
  --context-file "/Users/aiagnet/.openclaw/workspace/user.md" \
  --non-interactive
```

(If `--context-file` is not a supported flag in your OpenClaw version, set
`contextFiles` directly in `openclaw.json` under `agents.list[0]` as shown in
the config snippet — that is the canonical approach.)

### 9. Smoke test

```bash
# Test Maton auth
curl -sf -H "Authorization: Bearer $MATON_API_KEY" \
  "https://gateway.maton.ai/google-mail/gmail/v1/users/me/profile" | jq .

# Test a single email end-to-end
openclaw tool lobster run \
  --agent email-triage \
  --file ~/.openclaw/workspace/workflows/email-triage.lobster \
  --args-json '{"email_id":"PASTE_A_REAL_ID_HERE"}'
```

---

## Architecture summary

```
OpenClaw cron (15 min)
  └─ dispatcher.sh
       ├─ Maton API → fetch email IDs
       └─ openclaw tool lobster run (per email, inside managed context)
            └─ email-triage.lobster
                 ├─ fetch-email.sh       (Maton → email JSON)
                 ├─ classify-email.sh    (openclaw agent email-triage, Haiku)
                 │    └─ context: AGENTS.md + soul.md + user.md [loaded once]
                 │    └─ injected: triage-rules.md [dynamic data, per call]
                 ├─ mark-processed.sh    (Maton → apply label)
                 └─ route-and-act.sh     (Maton actions + Telegram gates)
                      └─ draft-reply.sh  (openclaw agent, soul.md tone applied)
```

## Why the identity files are split this way

| Concern | File | Update frequency |
|---|---|---|
| What the agent does, what it must never do | AGENTS.md | Rare — only when pipeline changes |
| How the agent writes and speaks | soul.md | Very rare — character is stable |
| Who Nay is, how he wants to be contacted | user.md | Occasional — as preferences change |
| Which senders go in which bucket | triage-rules.md (QMD) | Frequent — add senders anytime |

Mixing them would mean editing `AGENTS.md` every time you add a sender to the
spam list. Keeping them separate means triage-rules.md is the only file that
needs routine maintenance.
