#!/usr/bin/env bash
# dispatcher.sh — entry point for email triage (v2.5)
# Triggered by OpenClaw cron every 15 min.
# Fetches unprocessed email IDs via Maton API Gateway and runs
# email-triage.lobster for each via OpenClaw's lobster tool.
#
# v2.5 changes vs v2.4:
# - PATH fixed here so cron gets jq, curl, node@22
# - Gmail calls use Maton API Gateway (MATON_API_KEY bearer token)
# - Lobster invoked as plain shell binary `lobster run` (proven working in v2.4)
# - Telegram chat ID read from env/secrets file, not hardcoded

set -euo pipefail

# ── PATH: must cover node@22, homebrew (jq, curl) ───────────────────
export PATH="/usr/local/opt/node@22/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin"

LOCKFILE="/tmp/email-triage-dispatcher.lock"
WORKFLOW="${TRIAGE_WORKFLOW:-$HOME/.openclaw/workspace/workflows/email-triage.lobster}"
MATON_BASE="https://gateway.maton.ai/google-mail/gmail/v1/users/me"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-$(cat "$HOME/.openclaw/secrets/telegram-chat-id" 2>/dev/null || echo '')}"

# ── Overlap guard ────────────────────────────────────────────────────
if [ -f "$LOCKFILE" ]; then
  LOCK_AGE=$(( $(date +%s) - $(stat -f %m "$LOCKFILE" 2>/dev/null || echo 0) ))
  if [ "$LOCK_AGE" -lt 600 ]; then
    echo "Previous run still active (${LOCK_AGE}s old). Skipping."
    exit 0
  else
    echo "Stale lock (${LOCK_AGE}s). Removing and proceeding."
    rm -f "$LOCKFILE"
  fi
fi
trap 'rm -f "$LOCKFILE"' EXIT
touch "$LOCKFILE"

# ── Fetch unprocessed email IDs via Maton API Gateway ────────────────
# curl -G --data-urlencode handles query encoding without extra dependencies.
EMAIL_IDS=$(curl -sf -G \
  -H "Authorization: Bearer ${MATON_API_KEY}" \
  --data-urlencode "q=-label:Triage/Processed is:inbox newer_than:30d" \
  --data-urlencode "maxResults=50" \
  "${MATON_BASE}/messages" \
  2>/dev/null | jq -r '.messages[]?.id // empty')

if [ -z "$EMAIL_IDS" ]; then
  echo "No new emails to process."
  exit 0
fi

# ── Process each email via OpenClaw lobster tool ─────────────────────
# openclaw tool lobster run keeps execution inside OpenClaw's managed context
# so AGENTS.md, soul.md, user.md are available to the email-triage agent.
COUNT=0
ERRORS=0

for EMAIL_ID in $EMAIL_IDS; do
  echo "Processing: $EMAIL_ID"
  # lobster run as shell binary — proven working in v2.4.
  # Agent context (AGENTS.md, soul.md, user.md) is loaded per openclaw agent
  # call inside classify-email.sh and draft-reply.sh.
  if lobster run \
       --file "$WORKFLOW" \
       --args-json "{\"email_id\":\"$EMAIL_ID\"}" 2>/dev/null; then
    echo "  [$EMAIL_ID] done"
    COUNT=$((COUNT + 1))
  else
    echo "  [$EMAIL_ID] ERROR" >&2
    ERRORS=$((ERRORS + 1))
  fi
done

echo ""
echo "Done: $COUNT processed, $ERRORS errors."

# ── Notify Telegram only if something happened ───────────────────────
if [ $COUNT -gt 0 ] || [ $ERRORS -gt 0 ]; then
  MSG="📧 Email Triage Done"$'\n'"✅ $COUNT processed"
  [ $ERRORS -gt 0 ] && MSG="$MSG"$'\n'"⚠️ $ERRORS errors"
  openclaw message send \
    --channel telegram \
    --target "$TELEGRAM_CHAT_ID" \
    --message "$MSG" 2>/dev/null || true
fi
