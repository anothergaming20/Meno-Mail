# Boot checklist — Email Triage Agent

Run these checks silently on gateway restart. Use NO_REPLY if everything is
healthy. Only send a Telegram message if a check fails.

## Checks

1. Verify `data/label-ids.env` exists and is non-empty
   - If missing: alert Telegram — "Email triage: label-ids.env missing. Run setup-labels.sh."

2. Verify `MATON_API_KEY` is set in the environment
   - Check: `echo $MATON_API_KEY` — should be non-empty
   - If missing: alert Telegram — "Email triage: MATON_API_KEY not set. Check skill env config."

3. Verify `data/pending-drafts.json` exists (create empty `{}` if not)

4. Verify `~/.openclaw/secrets/telegram-chat-id` exists
   - If missing: alert Telegram via any available channel — "Telegram chat ID missing."

## On success

Reply with NO_REPLY. Do not send any message.

## On failure

Send one Telegram message per failed check. Keep messages concise.
