# Memory — Email Triage Agent

## Purpose

This file holds durable operational facts learned during triage runs. It
supplements `triage-rules.md` (which is manually authored) with facts the
agent discovers automatically. Write here when you learn something that should
change future triage behavior.

## When to write here

- A sender turns out to be a real person Nay has replied to → add to
  "Senders replied to" so they are never auto-trashed
- Nay dismisses a draft and gives a reason → note the pattern to improve
  future drafts
- A classification was wrong and Nay corrects it via Telegram → record the
  correction so the same email type is handled better next time
- A new VIP sender appears → note here until Nay adds them to triage-rules.md

## Senders replied to (never auto-trash)

<!-- Agent: append entries here as you discover them during triage runs -->
<!-- Format: - sender@domain.com — first seen YYYY-MM-DD -->

## Classification corrections

<!-- Agent: append corrections when Nay flags a wrong bucket -->
<!-- Format: - YYYY-MM-DD: [from] [subject snippet] was bucketed as X, should be Y. Reason: ... -->

## Draft style notes

<!-- Agent: append notes when Nay edits or dismisses drafts with feedback -->
<!-- Format: - YYYY-MM-DD: [pattern observed] -->

## Operational notes

<!-- Agent: append any recurring errors, Maton issues, or system observations -->
<!-- Format: - YYYY-MM-DD: [observation] -->
