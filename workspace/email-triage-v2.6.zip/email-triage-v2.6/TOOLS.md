# Tools — Email Triage Agent

## Runtime environment

- **Host**: Mac Mini M4 · macOS
- **Workspace**: `/Users/aiagnet/.openclaw/workspace/`
- **Node.js**: `/usr/local/opt/node@22/bin/` (must be on PATH for lobster and openclaw)
- **Homebrew**: `/opt/homebrew/bin/` (jq, curl)

## Key binaries and where they live

| Binary | Path | Notes |
|---|---|---|
| `lobster` | `/usr/local/opt/node@22/bin/lobster` | Run as shell binary via `exec` tool |
| `openclaw` | `/usr/local/opt/node@22/bin/openclaw` | CLI — use for `message send` only |
| `openclaw.invoke` | agent-internal | Available inside Lobster steps only |
| `jq` | `/opt/homebrew/bin/jq` | Required by all scripts |
| `curl` | `/usr/bin/curl` | Used for all Maton API calls |

## Environment variables (injected by OpenClaw skill env)

- `MATON_API_KEY` — injected via `skills.entries.gmail.env` in openclaw.json
- `TELEGRAM_CHAT_ID` — read from `~/.openclaw/secrets/telegram-chat-id`

## Important file paths

| File | Purpose |
|---|---|
| `scripts/run-triage.sh` | Main pipeline runner — call this via exec tool |
| `scripts/cleanup-stale-drafts.sh` | Stale draft cleanup — call via exec tool |
| `workflows/email-triage.lobster` | Per-email Lobster workflow |
| `memory/triage-rules.md` | Sender lists + classification rules (manually authored) |
| `MEMORY.md` | Agent operational learnings (write here after triage runs) |
| `data/label-ids.env` | Gmail label ID mapping (sourced by scripts) |
| `data/pending-drafts.json` | Drafts awaiting Telegram approval |
| `data/logs/triage.jsonl` | Structured per-run log |

## Maton API gateway

Base URL: `https://gateway.maton.ai/google-mail/gmail/v1/users/me/`

Key endpoints used:
- `GET  /messages?q=...` — list unprocessed emails
- `GET  /messages/{id}?format=full` — fetch full email
- `POST /messages/{id}/modify` — apply/remove Gmail labels
- `POST /messages/{id}/trash` — move to trash
- `POST /drafts` — save a draft
- `POST /drafts/send` — send a saved draft
- `POST /labels` — create a Gmail label (setup only)

Auth: `Authorization: Bearer $MATON_API_KEY`

## How to invoke the pipeline

From within a cron agentTurn session, use the exec tool:

```bash
bash /Users/aiagnet/.openclaw/workspace/scripts/run-triage.sh
```

Output is JSON: `{processed: N, errors: N, results: [...]}`.
If `errors > 0`, send a Telegram alert.

## What openclaw.invoke is and is not

`openclaw.invoke` is an agent-internal function available only when running
inside an OpenClaw agent session. It is accessible from Lobster step commands
(because Lobster runs inside the exec tool, which runs inside the agent session).

It is NOT available from:
- Bare cron commands (the old `command:` style — no longer used)
- Scripts called outside any agent context (e.g., send-approved-reply.sh
  triggered by Telegram button — use `openclaw message send` CLI instead)

## Lobster

Called as a shell binary: `lobster run --file <workflow> --args-json '{"key":"val"}'`

The workflow file (`email-triage.lobster`) chains four steps via stdin→stdout:
fetch → classify → mark_processed → route_and_act

Each step's stdout becomes the next step's stdin. Only the final step's stdout
reaches the calling script.
